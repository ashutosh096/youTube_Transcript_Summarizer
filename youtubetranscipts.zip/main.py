"""
YouTube Transcript Summarizer — FastAPI Backend
================================================
Run:  pip install -r requirements.txt
      uvicorn main:app --reload --port 8000
Open: http://localhost:8000
"""

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import re, os, textwrap, httpx

app = FastAPI(title="YT Summarizer", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)

# ── serve frontend ─────────────────────────────────────────
if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", include_in_schema=False)
def root():
    if os.path.exists("static/index.html"):
        return FileResponse("static/index.html")
    return {"message": "API running. Put index.html in /static/"}


# ── models ─────────────────────────────────────────────────
class SummarizeRequest(BaseModel):
    url: str
    style: str = "detailed"   # brief | detailed | bullets


# ── helpers ────────────────────────────────────────────────
def extract_video_id(url: str) -> str | None:
    patterns = [
        r"(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([A-Za-z0-9_-]{11})",
        r"youtube\.com/shorts/([A-Za-z0-9_-]{11})",
    ]
    for p in patterns:
        m = re.search(p, url)
        if m:
            return m.group(1)
    return None


async def get_transcript(video_id: str) -> dict:
    """
    Uses the youtube-transcript-api via a lightweight HTTP call.
    Falls back to a free public proxy endpoint.
    """
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
        raw = YouTubeTranscriptApi.get_transcript(video_id)
        text = " ".join(seg["text"] for seg in raw)
        duration = raw[-1]["start"] + raw[-1].get("duration", 0) if raw else 0
        return {"text": text, "segments": len(raw), "duration": int(duration)}
    except ImportError:
        # fallback: try public transcript proxy
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.get(
                f"https://ytranscript.vercel.app/api/transcript?videoId={video_id}"
            )
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, list):
                    text = " ".join(seg.get("text","") for seg in data)
                    return {"text": text, "segments": len(data), "duration": 0}
        raise HTTPException(500, "youtube-transcript-api not installed. Run: pip install youtube-transcript-api")
    except Exception as e:
        raise HTTPException(400, f"Could not fetch transcript: {str(e)}")


async def get_video_info(video_id: str) -> dict:
    """Fetch basic video metadata from oEmbed (no API key needed)."""
    try:
        async with httpx.AsyncClient(timeout=8) as client:
            r = await client.get(
                f"https://www.youtube.com/oembed?url=https://youtube.com/watch?v={video_id}&format=json"
            )
            if r.status_code == 200:
                d = r.json()
                return {
                    "title":    d.get("title", "Unknown Title"),
                    "channel":  d.get("author_name", "Unknown Channel"),
                    "thumbnail": d.get("thumbnail_url", ""),
                }
    except Exception:
        pass
    return {"title": "Unknown Title", "channel": "Unknown Channel", "thumbnail": ""}


def summarize_text(text: str, style: str) -> dict:
    """
    Summarize using Claude AI via the Anthropic API.
    Falls back to simple extractive summary if API not configured.
    """
    try:
        import anthropic
        client = anthropic.Anthropic()

        if style == "brief":
            instruction = "Write a concise 3-4 sentence summary of the key points."
        elif style == "bullets":
            instruction = "Extract the 6-8 most important points as clear bullet points starting with •"
        else:  # detailed
            instruction = "Write a detailed structured summary with: Overview (2-3 sentences), Key Topics covered, Main Takeaways, and Conclusion."

        msg = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{
                "role": "user",
                "content": f"""You are a YouTube transcript summarizer. {instruction}

Transcript:
{text[:12000]}

Respond ONLY with the summary, no preamble."""
            }]
        )
        summary = msg.content[0].text
        return {"summary": summary, "method": "ai"}

    except ImportError:
        pass
    except Exception:
        pass

    # ── Extractive fallback (no API key needed) ────────────
    sentences = re.split(r'(?<=[.!?])\s+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 40]
    step = max(1, len(sentences) // 8)
    picked = sentences[::step][:8]

    if style == "bullets":
        summary = "\n".join(f"• {s}" for s in picked)
    elif style == "brief":
        summary = " ".join(picked[:3])
    else:
        summary = " ".join(picked[:6])

    word_count = len(text.split())
    if word_count < 100:
        summary = "Transcript too short to summarize meaningfully.\n\n" + text

    return {"summary": summary, "method": "extractive"}


# ── main endpoint ──────────────────────────────────────────
@app.post("/api/summarize")
async def summarize(req: SummarizeRequest):
    # 1. extract video id
    vid = extract_video_id(req.url.strip())
    if not vid:
        raise HTTPException(400, "Invalid YouTube URL. Please use a valid youtube.com or youtu.be link.")

    # 2. fetch video info + transcript concurrently
    import asyncio
    info_task       = asyncio.create_task(get_video_info(vid))
    transcript_task = asyncio.create_task(get_transcript(vid))

    info      = await info_task
    transcript_data = await transcript_task

    # 3. summarize
    result = summarize_text(transcript_data["text"], req.style)

    word_count = len(transcript_data["text"].split())
    read_time  = max(1, round(word_count / 200))

    return {
        "video_id":     vid,
        "title":        info["title"],
        "channel":      info["channel"],
        "thumbnail":    info["thumbnail"],
        "summary":      result["summary"],
        "method":       result["method"],
        "word_count":   word_count,
        "read_time":    read_time,
        "segments":     transcript_data["segments"],
        "style":        req.style,
    }


@app.get("/api/health")
def health():
    return {"status": "ok"}
