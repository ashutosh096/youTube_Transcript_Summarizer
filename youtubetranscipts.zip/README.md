# TranscriptAI — YouTube Transcript Summarizer
### FastAPI + Claude AI + youtube-transcript-api

## Quick Start (3 commands)

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. (Optional but recommended) Set your Anthropic API key for AI summaries
# Windows:
set ANTHROPIC_API_KEY=your_key_here
# Mac/Linux:
export ANTHROPIC_API_KEY=your_key_here

# 3. Run the server
uvicorn main:app --reload --port 8000

# 4. Open browser → http://localhost:8000
```

## Get free Anthropic API key
1. Go to console.anthropic.com
2. Sign up → API Keys → Create Key
3. Free tier includes $5 credit — enough for hundreds of summaries

## Without API key
The app still works — it uses extractive summarization
(picks the most important sentences from the transcript automatically)

## Project Files
```
yt-summarizer/
├── main.py              ← FastAPI backend
├── requirements.txt     ← Python dependencies
└── static/
    └── index.html       ← Full frontend
```

## Features
- Paste any YouTube URL
- 3 summary styles: Brief / Detailed / Bullet Points
- Copy to clipboard + Download as .txt
- Shows video title, channel, word count
- Works with youtube.com, youtu.be, and Shorts
